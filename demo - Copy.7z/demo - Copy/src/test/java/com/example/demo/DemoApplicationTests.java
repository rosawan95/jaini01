package com.example.demo;

import org.junit.Test;
import org.junit.runner.RunWith;


public class DemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
